"use strict";

//maybe one day they'll fix their bundled chai module
//const expect = require('chai').expect;

const router = require('../index.js');
const assert = require('assert');

describe('handlers', function () {
  describe('connectionsPut', function () {
    // TODO: make tests using a sinon stub for res with "send" and "throw" for various good and bad inputs

    // it('should not accept a value in the future', function(){
    //   const future = 234567890123456;
  });
});
