"use strict";

const db = require('../db.js');

describe('groups', function () {
  // it('should be able to create a group', function () {
  //   db.createGroup('a', 'b', 'c', Date.now());
  // });
});